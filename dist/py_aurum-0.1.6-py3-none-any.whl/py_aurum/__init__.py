__version__ = '0.1.6'

from .py_aurum import Aurum

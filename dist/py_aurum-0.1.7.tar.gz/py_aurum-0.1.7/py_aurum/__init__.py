__version__ = '0.1.7'

from .py_aurum import Aurum

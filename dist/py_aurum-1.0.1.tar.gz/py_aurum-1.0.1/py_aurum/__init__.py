__version__ = '1.0.1'

from .py_aurum import Aurum

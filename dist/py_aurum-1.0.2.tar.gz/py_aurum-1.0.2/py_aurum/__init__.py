__version__ = '1.0.2'

from .py_aurum import Aurum
